<?php
class Database {


    public function __construct()
    {

    }

    public function connect() {

    }

    public function disconnect() {

    }

}